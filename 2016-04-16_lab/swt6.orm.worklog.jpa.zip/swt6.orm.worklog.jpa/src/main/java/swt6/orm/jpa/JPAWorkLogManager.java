package swt6.orm.jpa;

import java.text.DateFormat;

import swt6.orm.domain.annotated.Address;
import swt6.orm.domain.annotated.Employee;
import swt6.orm.domain.annotated.PermanentEmployee;
import swt6.orm.domain.annotated.TemporaryEmployee;
import swt6.util.DateUtil;

public class JPAWorkLogManager {
  private static final DateFormat fmt = DateFormat.getDateTimeInstance();

  private static Long saveEmployee(Employee empl) {
    // TODO implement
    return null;
  }

  private static void listEmployees() {
    // TODO implement
  }

  private static void addLogbookEntries(Employee empl) {
    // TODO implement
  }

  private static void getEmployee(long emplId) {
    // TODO implement
  }

  private static void getLogbookEntry(long entryId) {
    // TODO implement
  }

  private static void assignProjectsToEmployees(Employee empl1, Employee empl2) {
    // TODO implement
  }

  private static void listLogbookEntriesOfEmployee(Employee empl1) {
    // TODO implement
  }

  public static void listEmployeesOfProject(Long projectId) {
    // TODO implement
  }

  public static void main(String[] args) {
    try {
      System.out.println("----- create schema -----");
      JPAUtil.getEntityManager();

      Employee empl1 = new Employee("Franz", "Mayr", DateUtil.getDate(1980, 12, 24));
      Employee empl2 = new Employee("Bill", "Gates", DateUtil.getDate(1970, 1, 21));
      // empl1.setAddress(new Address("4232", "Hagenberg", "Hauptstraße 1"));
      // empl2.setAddress(new Address("77777", "Redmond", "Clinton Street"));

      // PermanentEmployee empl1 = new PermanentEmployee("Franz", "Mayr", DateUtil.getDate(1980, 12, 24));
      // empl1.setAddress(new Address("4232", "Hagenberg", "Hauptstraße 1"));
      // empl1.setSalary(5000.0);
      //
      // TemporaryEmployee empl2 = new TemporaryEmployee("Bill", "Gates", DateUtil.getDate(1970, 1, 21));
      // empl2.setAddress(new Address("77777", "Redmond", "Clinton Street"));
      // empl2.setHourlyRate(50.0);
      // empl2.setRenter("Microsoft");
      // empl2.setStartDate(DateUtil.getDate(2006, 3, 1));
      // empl2.setEndDate(DateUtil.getDate(2006, 4, 1));

      System.out.println("----- saveEmployee -----");
      saveEmployee(empl1);

      System.out.println("----- saveEmployee -----");
      saveEmployee(empl2);

      System.out.println("----- getEmployee -----");
      // getEmployee(empl2.getId());

      System.out.println("----- addLogbookEntries -----");
      addLogbookEntries(empl1);

      System.out.println("----- listEmployees -----");
      listEmployees();

      System.out.println("----- getLogbookEntry -----");
      getLogbookEntry(1L);

      System.out.println("----- assignProjectsToEmployees -----");
      assignProjectsToEmployees(empl1, empl2);

      System.out.println("----- listEmployeesOfProject -----");
      listEmployeesOfProject(32768L);
      listEmployeesOfProject(32769L);

      System.out.println("----- listEmployees -----");
      listEmployees();

      System.out.println("----- listLogbookEntriesOfEmployee -----");
      listLogbookEntriesOfEmployee(empl1);
    } finally {
      JPAUtil.closeEntityManagerFactory();
    }
  }

}
